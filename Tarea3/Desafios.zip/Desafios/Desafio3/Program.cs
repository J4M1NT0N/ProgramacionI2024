﻿using System;

public class Metodo_static
{
    public static void Main(string[] args)
    {
        try
        {
            int resultado = SumaDeValores();
            Console.WriteLine("La suma de los dos valores es: " + resultado);
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
        }
    }

    public static int SumaDeValores()
    {
        int valor1 = 0, valor2 = 0;

        try
        {
            Console.WriteLine("Ingrese el primer valor:");
            string input1 = Console.ReadLine();
            //  la funcion (string.IsNullOrWhiteSpace(input1)) sirve para saber si un espacio esta en blanco
            if (string.IsNullOrWhiteSpace(input1))
            {
                throw new Exception("No se ha ingresado ningún valor.");
            }

            if (!int.TryParse(input1, out valor1))
            {
                throw new FormatException("El valor ingresado no es un número válido.");
            }

            Console.WriteLine("Ingrese el segundo valor:");
            string input2 = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(input2))
            {
                throw new Exception("No se ha ingresado ningún valor.");
            }

            if (!int.TryParse(input2, out valor2))
            {
                throw new FormatException("El valor ingresado no es un número válido.");
            }
        }
        // la funcion finally se mostrara siempre
        finally
        {
            Console.WriteLine("Operación finalizada");
        }

        return valor1 + valor2;
    }
}
