﻿using System;

public class Usuario
{
    public string NombreUsuario { get; set; }
    public string Contraseña { get; set; }
}

public class InicioDeSesion
{
    private static List<Usuario> usuariosRegistrados = new List<Usuario>();

    public static void Main(string[] args)
    {
        bool salir = false;

        while (!salir)
        {
            Console.WriteLine("Bienvenido al sistema de inicio de sesión:");
            Console.WriteLine("1. Registrarse");
            Console.WriteLine("2. Iniciar sesión");
            Console.WriteLine("3. Salir");
            Console.Write("Seleccione una opción: ");

            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    RegistroDeUsuario();
                    break;
                case "2":
                    IniciarSesion();
                    break;
                case "3":
                    salir = true;
                    break;
                default:
                    Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                    break;
            }
        }
    }

    public static void RegistroDeUsuario()
    {
        Console.WriteLine("Por favor, ingrese un nombre de usuario:");
        string nombreUsuario = Console.ReadLine();

        // Esto es para verificar si el usuario ya esta registrado
        bool usuarioExistente = usuariosRegistrados.Exists(u => u.NombreUsuario == nombreUsuario);

        if (usuarioExistente)
        {
            Console.WriteLine("El usuario ya está registrado. Por favor, inicie sesión o elija otro nombre de usuario.");
        }
        else
        {
            Console.WriteLine("Por favor, ingrese una contraseña:");
            string contraseña = Console.ReadLine();

            Usuario nuevoUsuario = new Usuario
            {
                NombreUsuario = nombreUsuario,
                Contraseña = contraseña
            };

            usuariosRegistrados.Add(nuevoUsuario);

            Console.WriteLine("¡Usuario registrado exitosamente!");
        }
    }


    public static void IniciarSesion()
    {
        Console.WriteLine("Por favor, ingrese su nombre de usuario:");
        string nombreUsuario = Console.ReadLine();

        Console.WriteLine("Por favor, ingrese su contraseña:");
        string contraseña = Console.ReadLine();

        bool usuarioEncontrado = false;

        foreach (Usuario usuario in usuariosRegistrados)
        {
            if (usuario.NombreUsuario == nombreUsuario && usuario.Contraseña == contraseña)
            {
                usuarioEncontrado = true;
                Console.WriteLine("Inicio de sesión exitoso. ¡Bienvenido, " + nombreUsuario + "!");
                break;
            }
        }

        if (!usuarioEncontrado)
        {
            Console.WriteLine("Nombre de usuario o contraseña incorrectos. Inténtelo de nuevo.");
        }
    }
}
