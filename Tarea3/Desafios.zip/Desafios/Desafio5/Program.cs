﻿using System;

public class Puntajes
{
    private int puntaje;
    private int puntajeRecord;
    private string jugadorRecord;

    public Puntajes()
    {
        puntaje = 0;
        puntajeRecord = 0;
        jugadorRecord = "";
    }

    public void RegistroDePuntaje()
    {
        Console.WriteLine("Ingrese el puntaje:");
        int nuevoPuntaje = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Ingrese nombre del jugador:");
        string nombreJugador = Console.ReadLine();

        puntaje = nuevoPuntaje;

        if (puntaje > puntajeRecord)
        {
            puntajeRecord = puntaje;
            jugadorRecord = nombreJugador;

            Console.WriteLine("¡Nueva puntuación más alta! " + puntajeRecord + " puntos logrados por " + jugadorRecord);
        }
        else
        {
            Console.WriteLine("La puntuación más alta de " + puntajeRecord + " no se ha podido superar, y aún está en manos de " + jugadorRecord);
        }
    }

    public void MostrarPuntaje()
    {
        Console.WriteLine("Puntaje actual: " + puntaje);
        Console.WriteLine("Récord actual: " + puntajeRecord + " puntos, establecido por " + jugadorRecord);
    }
}

class Program
{
    static void Main(string[] args)
    {
        Puntajes puntaje = new Puntajes();
         
        puntaje.RegistroDePuntaje();
        puntaje.MostrarPuntaje();

        puntaje.RegistroDePuntaje();
        puntaje.MostrarPuntaje();

        puntaje.RegistroDePuntaje();
        puntaje.MostrarPuntaje();
    }
}
