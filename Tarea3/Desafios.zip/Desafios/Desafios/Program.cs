﻿using System;

public class Ingresos3M
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Ingrese su nombre:");
        string nombreUsuario = Console.ReadLine();

        Console.WriteLine("Ingrese los ingresos del mes 1:");
        double ingresosMes1 = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Ingrese los ingresos del mes 2:");
        double ingresosMes2 = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Ingrese los ingresos del mes 3:");
        double ingresosMes3 = Convert.ToDouble(Console.ReadLine());

        ImprimirIngresos(nombreUsuario, ingresosMes1, ingresosMes2, ingresosMes3);
    }

    public static void ImprimirIngresos(string nombreUsuario, double ingresosMes1, double ingresosMes2, double ingresosMes3)
    {
        double sumaIngresos = ingresosMes1 + ingresosMes2 + ingresosMes3;
        double promedioIngresos = sumaIngresos / 3;

        Console.WriteLine($"Hola {nombreUsuario}, en total has ganado {sumaIngresos} y tuviste un promedio de {promedioIngresos}");
    }
}
